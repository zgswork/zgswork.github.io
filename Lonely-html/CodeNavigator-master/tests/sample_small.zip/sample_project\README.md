# 示例项目

这是一个用于测试 Code Navigator 工具的示例项目。它包含了多种编程语言的示例代码，用于演示工具的各项功能。

## 项目结构

```
sample_project/
├─ js/                 # JavaScript 代码
│  └─ main.js         # 主 JavaScript 文件
├─ python/             # Python 代码
│  └─ main.py         # 主 Python 文件
├─ java/               # Java 代码
│  └─ Main.java       # 主 Java 文件
└─ README.md          # 项目说明文档
```

## 功能演示

这个示例项目包含了以下功能的演示：
- 函数定义和调用
- 类定义和实例化
- 变量和常量定义
- 基本的控制流语句
- 代码注释

## 使用方法

将整个项目压缩为 ZIP 文件，然后上传到 Code Navigator 工具中进行浏览和分析。