// JavaScript 示例文件
function greet(name) {
    return `Hello, ${name}!`;
}

const PI = 3.14159;
let counter = 0;

class Calculator {
    add(a, b) {
        return a + b;
    }

    multiply(a, b) {
        return a * b;
    }
}

const calc = new Calculator();
console.log(calc.add(2, 3));
console.log(greet('World'));