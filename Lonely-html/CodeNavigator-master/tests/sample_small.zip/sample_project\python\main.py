# Python 示例文件
def fibonacci(n):
    """计算斐波那契数列"""
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

class DataProcessor:
    def __init__(self, data):
        self.data = data

    def process(self):
        """处理数据"""
        result = []
        for item in self.data:
            if item > 0:
                result.append(item * 2)
        return result

# 全局变量
MAX_ITERATIONS = 100
VERSION = "1.0.0"

# 使用示例
processor = DataProcessor([1, -2, 3, -4, 5])
print(processor.process())
print(fibonacci(10))