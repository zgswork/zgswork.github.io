// Java 示例文件
public class Main {
    private static final String APP_NAME = "CodeNavigator";
    private static final int VERSION = 1;

    public static void main(String[] args) {
        System.out.println("Welcome to " + APP_NAME + " v" + VERSION);

        Main main = new Main();
        main.demo();
    }

    public void demo() {
        Calculator calc = new Calculator();
        int result = calc.add(5, 3);
        System.out.println("5 + 3 = " + result);
    }
}

class Calculator {
    public int add(int a, int b) {
        return a + b;
    }

    public int multiply(int a, int b) {
        return a * b;
    }

    public double divide(int a, int b) {
        if (b == 0) {
            throw new IllegalArgumentException("Cannot divide by zero");
        }
        return (double) a / b;
    }
}